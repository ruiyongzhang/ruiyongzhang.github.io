 
# 2021-3DBuilding
#### contributors : David Zhan, Stephen Brock, Ziqing Zhang, Ruiyong Zhang with [contribution](https://github.com/spe-uob/2021-3DBuilding/graphs/contributors)
## Category
* [2021-3DBuilding](https://github.com/spe-uob/2021-3DBuilding#2021-3dbuilding)
  * [Contributors] 
* [Project brief](https://github.com/spe-uob/2021-3DBuilding#project-brief)
  * [Necessary requirements] 
  * [Client's statement]
  * [User stories]   
* [Preknowledge required](https://github.com/spe-uob/2021-3DBuilding#preknowledge-required) 
* [How to access our web application](https://github.com/spe-uob/2021-3DBuilding#How-to-access-our-web-application)
* [Local access]
* [Remote access]
* [Deploy instructions](https://github.com/spe-uob/2021-3DBuilding#Deploy-instructions)
* [Documentation](https://github.com/spe-uob/2021-3DBuilding#documentation)
* [Developing](https://github.com/spe-uob/2021-3DBuilding#contributing)
  * [Developing guide]
  * [expected development] 
* [License](https://github.com/spe-uob/2021-3DBuilding#license)
* [Ethics](https://github.com/spe-uob/2021-3DBuilding#eithics)
* [First feedback from MVP](https://github.com/spe-uob/2021-3DBuilding/blob/master/README.md#first-feedback-from-mvp)
## Project brief
When it comes to finding rooms in different buildings, there are always many difficulties.
The client has been working in the university for almost 30 years and still get lost. 
Sometimes for finding meeting rooms. This led us to an aim that find out an application which is capable of finding any room of the building when we put in its room number, and give out a perfect path from user's location to that room. 
### 1.Client's statement
A Touch screen 'help point' that will show a virtual 3D model of a building, its floors, rooms, and labs.
### 2.Necessary requirements
In this project:  
1. A 3D model is required to show user the overview of the building and pathes.  
2. A path finding algorithm is required to find out the shortest path  
3. Users should be able to touch the screen to input the room number they intend to go to.
4. If the location and destination are on different floors, yser can choose either use the elevator orstairs.
### 3.User stories
#### 3.1 Our client Rich Walker
* Most buildings are difficult to find your way around - especially if you are new.   
* For older University buildings, having had additional wings/rooms/stairs etc - it can be very easy to become lost.  
* An interactive 3D floor plan that is searchable would be very useful.
#### 3.2 Students studying in MVB
* We have interviewed some student, and most of them found it hard to find out the way to study room at the beginning  
of the academic term. Also, although have been studying in MVB for a whole year, many of them still have no idea that  
MVB have seven floors in total, which implies that it is hard for them to find another meeting room in MVB. Consequently,  
an app which shows the path from any room to another would be helpful.
#### 3.3 Staff of the university
* According to some of the lecturers, it will be helpful to have a path guiding application when they have a meeting in some  
buildings they are not familiar with. Moreover, this kind of app will also help students find their classroom easier and  
faster, which may reduce occasion of being last.
## Preknowledge required
* [View prekonwledge required](docs/Preknowledge%20required.md)
## How to access our web application
### 1.Local access
#### Requirements
* [Github](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git)<br>
* Java 11 JDK<br>
* [Maven](https://maven.apache.org/)<br>
#### Downloading
Use git clone to clone this repository to your pc and change directory to 2021-3DBuilding.

```bash
git clone https://github.com/spe-uob/2021-3DBuilding
cd 2021-3DBuilding
```
#### Building
Build the project with Maven.

```bash
mvn install
```
You will see BUILD SUCCESS in green.

#### Running
Run the Spring-boot application,

```bash
java -jar target/demo-0.0.1-SNAPSHOT.jar --server.port=8080
```
Type [localhost:8080](https://localhost:8080) in your browser, you will see our web application.

### 2.Remote access (recommend)
#### Requirements
* A browser
#### Click the link
This a Kubernetes service hosted on the IBM cloud, what you need to do is just click on the link.<br>
[https://group-3dbuilding.classroom-eu-gb-1-bx2-4x1-d4ceb080620f0ec34cd169ad110144ef-0000.eu-gb.containers.appdomain.cloud](https://group-3dbuilding.classroom-eu-gb-1-bx2-4x1-d4ceb080620f0ec34cd169ad110144ef-0000.eu-gb.containers.appdomain.cloud)


## Deploy instructions
* The deploy method we recommend is _Kubernetes_.<br>
[The advantage of kubernetes](docs/deploy-instruction/why%20we%20choose%20kubernetes(deployment%20mode).pdf)<br>
[View deploy instructions](docs/deploy-instruction/deploy-instructions.md)<br>

## Documentation
[View documentation](docs/documentation/Documantation.md)<br>

## Developing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

#### 1.developing guide
Download the latest code
```bash
git pull origin master
```
Create a new branch
```bash
git branch <newBranchName>
```
Switch to the new branch you create
```bash
git checkout <newBranchName>
```
Push the local branch you have created to remote for later submission of your code.
```bash
git push origin <newBranchName>
```
After adding code to your branch, you can open a pull request. Please wait us to view your code and merge your pull request.
#### 2.expected development
You are welcome to contribute on:  
1. creat turning nodes for path showing on model
2. implement stair/floor prefernece


## License
[MIT](https://choosealicense.com/licenses/mit/)

## Ethics
No personal data is collected as part of this project.

## First feedback from MVP
[here](https://github.com/David-Zhan/workspace-1/blob/main/feedback) is the first feedback we get from MVP.  
You can also go to [here](https://github.com/David-Zhan/workspace-1/blob/main/CS%20Project%20review%5B34%5D.docx) to download it.  
You should click "view raw" to download it
