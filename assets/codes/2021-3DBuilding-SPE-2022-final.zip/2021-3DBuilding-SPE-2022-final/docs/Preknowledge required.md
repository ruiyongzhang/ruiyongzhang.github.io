# Preknowledge required

#### 1.Modeling

We use p5.js for modeling, you can click [here](https://p5js.org) for brief overview of p5.js  
[here](https://p5js.org/download/) is to download p5.js library
You may find some useful knowledge about p5.js [here](https://p5js.org/get-started/)

#### 2.Pathfinding
We simply use java for pathfinding.  
You may download [intellij IDEA](https://www.jetbrains.com/idea/)for running java code.  
We use [Dijkstra](https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm) algorithm for pathfinding.  
You should have a good understanding of it if you want to engage in doing pathfinding development.

#### 3.Web maintenance
we are hosting our web application on [IBM](https://www.ibm.com/cloud)    
we are currently working on docker files and some errors in comfirg file.  
you are welcome to devote in that part if you are capable of.  
[here](https://developer.ibm.com/tutorials/)is a tutorial might help.


#### 4. UI design
[here](https://careerfoundry.com/en/courses/become-a-ui-designer/?utm_campaign=10055918311&utm_term=learn%20user%20interface%20design&utm_source=google&utm_medium=cpc&utm_content=537837934235&hsa_src=g&hsa_ver=3&hsa_cam=10055918311&hsa_kw=learn%20user%20interface%20design&hsa_ad=537837934235&hsa_tgt=kwd-321733009372&hsa_mt=e&hsa_acc=9937848978&hsa_grp=121124676168&hsa_net=adwords&gclid=CjwKCAiAgbiQBhAHEiwAuQ6Bkm7fqlPVX3vyv1QBrj_U3YP351OY0NAjhGrnOWzG6MVwOyH5kChy2RoCKsYQAvD_BwE) are some lessons for UI design.  