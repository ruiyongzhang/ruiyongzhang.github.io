# Deploy instructions
## 1.Fork our GitHub repository
1.Click on _Fork_ button in [2021-3DBuilding github page](https://github.com/spe-uob/2021-3DBuilding)
## 2.Create Springboot Toolchain
1.Login in to IBM Cloud account, go to [toolchains](https://cloud.ibm.com/devops/toolchains?env_id=ibm:yp:eu-gb).<br>
2.Select your _resource group_ as your individual group name and the _location_ is London.<br>
3.Click _Create toolchain_.<br>
4.Click _Develop a Kubernetes App_.<br>
5.Enter the name of your toolchain and change select the _source provider_ to GitHub.<br>
6.Change _Clone_ to _Existing_ and select the repository you want to deploy.<br>
7.Click on _Delivery Pipeline_. Clicking _New +_ to add new IBM Cloud API key.<br>
8.Enter the name of your application.<br>
9.Make sure you provide the correct _Cluster namespace_. The namespace should follows this pattern: group-<lowercaseprojectname>.<br>
10.Click _Create_ to create the toolchain.<br>

## 3.Setting Springboot Toolchain configuration
Before the first deployment, we need to set up some configurations by clicking the _delievery pipeline_.<br>
#### 1.Build stage
1.Click the gear button to the left of _Build_ and choose _Configure Stage_.<br>
2.Click _Input_ , make sure the repository and branch is the one you want to deploy.<br>
3.Click the Job tab, selcet the _builder type_ to _Maven_.<br>
4.Inside _Build script_, enter<br>
```bash
#!/bin/bash
mvn -B package -DskipTests=True
```
5.Click Save.<br>
#### 2.Containerize stage
1.Click the gear button to the left of _Containerize_ and choose _Configure Stage_.<br>
2.Click the Jobs tab and switch the _Tester Type_ to _Simple_.<br>
3.Click _Save_.<br>

#### 3.Deploy stage
1.Click the gear button to the left of _Deploy_ and choose _Configure Stage_.<br>
2.Click the Jobs tab and inside _Deploy script_, enter<br>

```bash
source ./scripts/check_and_deploy_kubectl.sh
```
This operation requires check_and_deploy_kubectl.sh in your repository and its directory is
```bash
./scripts/check_and_deploy_kubectl.sh
```
 You can also source it from online script<br>
 ```bash
source <(curl -sSL "${COMMONS_HOSTED_REGION}/scripts/check_and_deploy_kubectl.sh")
```
3.Click Save.<br>

Our configuration is now complete, click the _Play_ button to deploy your application.<br>

## 4.View application
When the _Deploy stage_ shows a green tick indicating that you have successfully deployed your APP, click on _Deploy to Kubernetes_ and read the end of the log. Click on the url after the sentance _DEPLOYMENT SUCCEEDED VIEW THE APPLICATION AT_, you will see the application in your browser.<br>