# Documentation
## UML Diagrams
#### Class diagram
  ![UML Class Diagram ](class-diagram.png)
  * _SceneObject_ instances contain all the data and functionality to load a model with a certain material.
  * _Material_ instances contain the data and functionality to set the attributes of the shader for the required material. This is called by _SceneObject_ before rendering the model so that the model is rendered with unique attributes (e.g. colour, texture, roughness etc.).
  * A _Scene_ instance contains a collection of _SceneObject_ instances to render at once. This is used in this project to store all the _SceneObject_ instances that make up a certain floor in a _Scene_.
  * The data classes (_SceneObjectData_ and _MaterialData_) exist only to be written to JSON via JavaScript. The JSON is read to create instances of the realized classes (_SceneObject_ and _Material_) in global factory functions (_sceneLoaded_ and _loadMaterials_).
  * _SkyAmbient_ is only constructed once and was only made a class for the ease of changing attributes or functionality (e.g. by replacing _SkyAmbient_ with another class with the same _applyAmbient_ function). The class functions are responsible for applying the attributes to the shader for adjusting ambient colours and lighting.
#### Sequence diagram
![UML Sequence Diagram ](sequence-diagram.png)
#### Deploy diagram
![UML Deploy Diagram ](deploy-diagram.png)
## Data storing:
1. Why we choose static data over database:
database have advantage for dynamic data. However, the project is for finding path in a building and the rooms,locations can hardly change. COnsequently, using static data rather than database is efficient and reasonable.
2. How do we store our data: 
we are useing 20*20 matrix to store room location. which is a Two-dimensional array in java. the row number stand for the node number (room number), and the collom stand for the distance between this room to anther rooms.
3. why do we choose matrix over linked list: 
this is related to the time complexity，and space comsumed. since we are using dijkstra algorithm for pathfinding, the time complexity will always be O(nlogn) no matter we use matrix or lists, and we will consume more space by useing liked lists. Consequently, we choose using Two-dimensional array rather than linked lists.


## Pathfinding:
 * Algorithm : We choose dijkstra algorithm for pathfinding.
 * Process: As shown on the graph, the data received from frontend is frist sent to run.java, the data will be analized and find out whether the roomnumber is valid there and get the node number for each room. then the path will be found by runner.java, using algorithm in dPathfinding.java and data stored in floor.java. And the path will be delivered after processed by converter.java and room2.java (change the number 0-19 to a real roomnumber). After doing this, the path will be packed in a List and send to the Modeling part.

## UI Design
![UI diagram](User%20Interface%20(UI)%20Design%20Documentation_00.png)
![UI diagram](User%20Interface%20(UI)%20Design%20Documentation_01.png)
![UI diagram](User%20Interface%20(UI)%20Design%20Documentation_02.png)
![UI diagram](User%20Interface%20(UI)%20Design%20Documentation_03.png)