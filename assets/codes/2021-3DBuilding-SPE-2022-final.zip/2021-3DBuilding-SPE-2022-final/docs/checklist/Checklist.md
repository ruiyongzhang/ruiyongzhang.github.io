# Release Checklist

This checklist must be submitted by each group for each release.

Release Name: (MVP)
 
Date:9/12/2021

Microsoft Stream Screencast URL: https://web.microsoftstream.com/video/3b0f05e7-0acc-4e60-b8db-050693818d64

## Checks
- [tick] 3 named User Stories implemented
- [tick] Test cases successfully passed
- [tick] System deployed, accessible to the client 
- [ ] Client successfully interacted with system

## Notes