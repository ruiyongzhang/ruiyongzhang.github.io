
//stores camera data
var cam;
//for delta mouse position
var isRotating = false;
var lastMouseX;
var lastMouseY;
var camX = 0;
var camY = -1;
//velocity
var camVeloX = 0;
var camVeloY = 0;

//zoom multiplier
var zoom = 1.0;

//materials for turning transparent when the camera moves
//set in setupTransparencyMaterials()
var transparencyMaterials = [];
const TRANSPARENCY_MATERIAL_NAMES = ["walls", "doors"];
var transparencyAlpha = 1;

const SENSITIVITY = 0.000005;
const HEIGHT_MULTIPLIER = 3;
//min/max zoom clamp
const MIN_ZOOM = 0.4;
const MAX_ZOOM = 1.2;
//zoom increment step
const ZOOM_STEP = 0.2;
const DISTANCE_MULTIPLIER = 400;
const DAMPENING = 0.008;
//lower = less movement required to make walls transparent
const CAMERA_TRANSPARENCY_THRESHOLD = 0.0002;
//time taken for walls to become transparent
const CAMERA_TRANSPARENCY_TIME = 1.2;

function setupTransparencyMaterials() {
    for (let i = 0; i < TRANSPARENCY_MATERIAL_NAMES.length; i++) {
        console.log(i, TRANSPARENCY_MATERIAL_NAMES[i], materialDictionary[TRANSPARENCY_MATERIAL_NAMES[i]]);
        transparencyMaterials.push(materialDictionary[TRANSPARENCY_MATERIAL_NAMES[i]]);
    }
}

//called by button in index.html
function zoomIn() {
    zoom -= ZOOM_STEP;
    //clamp zoom to avoid clipping
    zoom = zoom < MIN_ZOOM ? MIN_ZOOM : zoom;
}

//called by button in index.html
function zoomOut() {
    zoom += ZOOM_STEP;
    //clamp zoom to avoid going too far away from the model
    zoom = zoom > MAX_ZOOM ? MAX_ZOOM : zoom;
}

//if mouse is pressed in canvas, start movement
function mousePressed() {
    if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
        isRotating = true;
        lastMouseX = mouseX;
        lastMouseY = mouseY;
    }
}

//stop movement
function mouseReleased() {
    isRotating = false;
}

//allows for panning around the model while keeping focussed on the origin
function cameraMovement() {
    //acceleration * dt = change in velocity
    camVeloX += (mouseX - lastMouseX) * SENSITIVITY * deltaTime;
    camVeloY += (mouseY - lastMouseY) * SENSITIVITY * deltaTime;

    lastMouseX = mouseX;
    lastMouseY = mouseY;
}

//dampen camera velocity
function cameraTick() {
    if (isRotating) {
        cameraMovement();
    }

    //dampen the velocity to create smoother movement
    //scale by 0 <= t <= 1
    let t = DAMPENING * deltaTime;
    t = t > 1 ? 1 : t;
    camVeloX = camVeloX * (1 - t);
    camVeloY = camVeloY * (1 - t);

    //determine whether the camera velocity is bigger than the threshold
    let alphaT = (abs(camVeloX) + abs(camVeloY)) > CAMERA_TRANSPARENCY_THRESHOLD ? -1 : 1;
    //step wall alpha towards 0 or 1 depending on if the camera velocity is greater than the threshold
    transparencyAlpha = transparencyAlpha + alphaT * t / CAMERA_TRANSPARENCY_TIME;
    //clamp between 0 and 1
    transparencyAlpha = transparencyAlpha > 1 ? 1 : transparencyAlpha < 0 ? 0 : transparencyAlpha;
    //set alpha of wall material to velocity of camera
    //so you can see rooms better when panning around
    for (let i = 0; i < transparencyMaterials.length; i++) {
        transparencyMaterials[i].setAlpha(transparencyAlpha);
    }

    //velo * dt = change in position
    camX += camVeloX * deltaTime;
    camY += camVeloY * deltaTime;

    //clamp withing reasonable range
    camY = camY > PI ? PI : (camY < -PI ? -PI : camY);

    //angles in radians
    //multiply distance by zoom
    let pos = createVector(sin(camX), camY * HEIGHT_MULTIPLIER, cos(camX)).normalize().mult(DISTANCE_MULTIPLIER * zoom);
    cam.setPosition(pos.x, pos.y, pos.z);
    //look at world origin
    cam.lookAt(0,0,0);
}
