

// //legacy implementation
// //array of all room positions on 3D model, ordered by room index
// var roomPositions = [];
// //current path drawing lines
// var linePoints = [];

//new implementation
//dictionary, room name (e.g. 2.11) => 3D vector position on model
var dictionaryRoomPositions = {};
//current path on each floor
//2D array, index for each floor
var floorLinePoints = [];

const LINE_WIDTH = 10.0;
const SPHERE_SIZE = 1.0;

//legacy
//sets linePoints variable from newLine indices
// function setPath(newLine) {
//     linePoints = [];
//     for (let i = 0; i < newLine.length; i++) {
//         linePoints.push(roomPositions[newLine[i]]);
//     }
// }

//converts string array to an array of strings
//e.g. input "[2.11, 2.09, 2.05]" -> ["2.11", "2.09", "2.05"]
function stringToArray(str) {
    let arr = [];
    for (let i = 1; i < str.length; i++) {
        let x = "";
        while (i < str.length && (str[i] == ',' || str[i] == ']' || str[i] == ' ')) {
            i++;
        }
        while (i < str.length && str[i] != ',' && str[i] != ']' && str[i] != ' ') {
            x += str[i++];
        }
        arr.push(x);
    }
    return arr;
}


//new
//takes an array of room names as input
//e.g. setPathNew(["2.18", "2.25", "2c02", "2c03"]);
function setPathNew(newLine) {
    for (let i = 0; i < FloorPaths.length; i++) {
        floorLinePoints[i] = [];
    }

    let newLineArr = stringToArray(newLine);

    //reset drawing animation
    drawTime = 0;

    for (let i = 0; i < newLineArr.length; i++) {
        let floor = parseInt(newLineArr[i][0], 10);
        floorLinePoints[floor].push(dictionaryRoomPositions[newLineArr[i]]);
    }
}

//legacy
//sets roomPositions variable from roomPositions.json
// function loadPositions(posJson) {
//     roomPositions = new Array(posJson.positions.length);
//     for (let i = 0; i < roomPositions.length; i++) {
//         roomPositions[i] = posJson.positions[i];
//     }
// }

function loadDictionaryPositions(posJson) {
    posJson.positions.forEach((x) => {
        dictionaryRoomPositions[x.id] = createVector(x.pos[0], x.pos[1], x.pos[2]);
    });

    //set button to a function to get path from back end
    $(function () {
        $("#btn").click(function () {
            $.post({
                    url:"/a1",
                    data:{'name':$("#txtName").val(),
                        'origin':$("#txtOrigin").val()},
                    success:function(data) {
                        if (data === "they are exact same room"){
                            alert("they are exact same room")
                        }else if (data ==="invalid room number"){
                            alert("invalid room number")
                        }else if (data === "invalid room numberthey are exact same room"){
                            alert("invalid room number they are exact same room")
                        }else{   setPathNew(data)}


                    }
                }
            );
        })
    })
}

// //legacy
// //draws the line, called every frame
// function drawPath() {
//     push();
//     //positions need to be flipped on z-axis for some reason?
//     scale(1, 1, -1);
//     stroke(255,0,0);
//     strokeWeight(10);
//     for (let i = 0; i < linePoints.length - 1; i++) {
//         let v1 = linePoints[i];
//         let v2 = linePoints[i + 1];
//         line(v1[0], v1[1], v1[2], v2[0], v2[1], v2[2]);
//     }
//     pop();
// }

//new
//set from setPathNew
//t is transition time from 0 to 1
function drawPathNew(floorIndex, t) {
    push();
    //positions need to be flipped on z-axis for some reason?
    scale(1, 1, -1);
    resetShader();
    emissiveMaterial(255, 40, 40);
    stroke(255, 40, 40);
    for (let i = 0; i < floorLinePoints[floorIndex].length - 1; i++) {
        //animate drawing line
        let vt = ((t * floorLinePoints[floorIndex].length - 1) - i);
        //clamp between 0 and 1
        if (vt > 0) {
            let v1 = floorLinePoints[floorIndex][i];
            let v2 = floorLinePoints[floorIndex][i + 1];
            vt = vt > 1 ? 1 : vt;
            let dir = p5.Vector.sub(v2, v1).mult(vt);
            push();
            translate(v1.x, v1.y, v1.z);
            strokeWeight(LINE_WIDTH);
            line(0, 0, 0, dir.x, dir.y, dir.z);
            strokeWeight(0);
            sphere(SPHERE_SIZE);
            pop();
        }

        strokeWeight(0);
        if (t >= 1) {
            push();
            let p = floorLinePoints[floorIndex][floorLinePoints[floorIndex].length - 1];
            translate(p.x, p.y, p.z);
            sphere(SPHERE_SIZE);
            pop();
        }
    }
    pop();
}