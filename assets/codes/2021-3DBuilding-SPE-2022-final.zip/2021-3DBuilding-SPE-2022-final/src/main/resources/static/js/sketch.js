//JSON storing material data
const MaterialsPath = "/Assets/materials.json";
//JSON storing 3D positions of rooms for path rendering
//legacy
// const RoomPositionsPath = "/Assets/roomPositions.json";
//new dictionary for storing positions with room names
const RoomDictionaryPositionsPath = "/Assets/nodePositions.json";
//JSON storing SceneObject models/materials/transformations
const FloorPaths = ["/Assets/floor-0.json", "/Assets/floor-1.json", "/Assets/floor-2.json", "/Assets/floor-3.json", "/Assets/floor-4.json", "/Assets/floor-5.json", "/Assets/floor-6.json"];
//Path for assets
const TexturesPath = "/Assets/Textures/";
const ShaderPath = "/Assets/Shaders/";
const ModelsPath = "/Assets/Models/";

//p5.js has arbitrary scale, scaling the whole scene so that everything is more within the clipping range
const ConstantScale = 8;

//preloaded shader
var generalShader;
//ambient object for setting ambient lighting
var ambient;

//maps material name to Material object
var materialDictionary;

//Scene for each floor contains all SceneObjects
var floors = [];
//set to default floor
var currentFloorIndex = 2;
//for changing floor animation
var previousFloorIndex = 0;
var switchTime = 1;
const SWITCH_SPEED = 0.002;
const SWITCH_HEIGHT = 10;

var drawTime = 0;

//called before setup/draw
//guarantees models/shaders/textures are loaded before they are referenced and drawn
function preload() {
    generalShader = loadShader(ShaderPath + 'general.vert', ShaderPath + 'general.frag');
    loadJSON(MaterialsPath, loadMaterials);
    //legacy
    // loadJSON(RoomPositionsPath, loadPositions);
    //new
    loadJSON(RoomDictionaryPositionsPath, loadDictionaryPositions);
}

//called once after preload and before draw
function setup() {
    for (let i = 0; i < FloorPaths.length; i++) {
        floorLinePoints[i] = [];
    }

    createCanvas(1600,800, WEBGL);
    cam = createCamera();

    //repeats UV coordinated to tile textures
    textureWrap(REPEAT);

    ambient = new SkyAmbient(
        createVector(0.1,0.05,0.0).mult(2.0),
        createVector(0.35,0.35,0.4).mult(1.0),
        createVector(0.1,0.35,0.5).mult(1.0), 1.0);

    setupTransparencyMaterials();

    shader(generalShader);
}

//called once per frame
function draw() {
    cameraTick();
    render();
}

function changeFloor(newFloor) {
    previousFloorIndex = currentFloorIndex;
    currentFloorIndex = newFloor;
    switchTime = 0;
}

function downFloor() {
    let newFloor = currentFloorIndex - 1;
    newFloor = newFloor < 0 ? 0 : newFloor;
    if (newFloor != currentFloorIndex) {
        changeFloor(newFloor);
    }
}

function upFloor() {
    let newFloor = currentFloorIndex + 1;
    newFloor = newFloor < FloorPaths.length ? newFloor : FloorPaths.length - 1;
    if (newFloor != currentFloorIndex) {
        changeFloor(newFloor);
    }
}

function keyPressed() {
    if (key == "ArrowDown") {
        downFloor();
    } else if (key == "ArrowUp") {
        upFloor();
    }
}

function floorSwitchAnimation(t) {
    //current floor to be rendered first for correct transparency sorting
    //in p5.js transparency is sorted by render call rather than distance
    push();
    translate(0, (1 - t) * (currentFloorIndex > previousFloorIndex ? SWITCH_HEIGHT : -SWITCH_HEIGHT), 0);
    drawPathNew(currentFloorIndex, t);
    floors[currentFloorIndex].render(generalShader, t);
    pop();
    push();
    translate(0, t * (currentFloorIndex > previousFloorIndex ? -SWITCH_HEIGHT : SWITCH_HEIGHT), 0);
    drawPathNew(previousFloorIndex, (1 - t) * drawTime);
    floors[previousFloorIndex].render(generalShader, 1 - t);
    pop();
}

//sets uniforms and renders the model with the material
function render() {
    directionalLight(255, 255, 255,-1,1,1);
    //clear canvas with transparent background
    background(0, 0, 0, 0);
    noStroke();

    ambient.applyAmbient(generalShader);
    push();
    //Models import flipped on X-axis for some reason?
    //maybe something weird with .obj files in p5.js
    scale(-ConstantScale, ConstantScale, ConstantScale);
    //accounting for Blender's flipped Y and Z axis
    rotateY(PI);
    rotateX(PI);

    //legacy
    // drawPath();
    if (switchTime < 1) {
        switchTime += SWITCH_SPEED * deltaTime;
        //smoothstep
        floorSwitchAnimation(switchTime * switchTime * (3 - 2 * switchTime));
    } else {
        //new implementation
        drawTime = drawTime > 1 ? 1 : drawTime + SWITCH_SPEED * deltaTime;
        drawPathNew(currentFloorIndex, drawTime);
        floors[currentFloorIndex].render(generalShader, 1);
    }

    pop();
}