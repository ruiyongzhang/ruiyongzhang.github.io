package com.example.demo.java;
//after finishing calculation the shortest path, I write this class to send String back to the code
//to give a List<String> to js part
public class roomLocator {
    String[] room_zero ={
            "050",//0
            "002",//1
            "001",//2
            "005",//3
            "010",//4
            "009",//5
            "0c01",//6
            "0c02",//7
            "012",//8
            "0c10",//9
            "004",//10
            "003",//11
            "008",//12
            "011",//13
            "0c05",//14
            "0c03",//15
            "0c11",//16
            "0c13",//17
            "0c14",//18
            "0c21",//19
    };
    String[] room_first ={
            "1.50",//0
            "1.10",//1
            "1.06",//2
            "1.07",//3
            "1.08",//4
            "1.14",//5
            "1.11",//6
            "1c02",//7
            "1c03",//8
            "1c10",//9
            "1.03",//10
            "1.02",//11
            "1.04",//12
            "1.09",//13
            "1.51",//14
            "1c01",//15
            "1.12",//16
            "1c11",//17

    };
    String[] room_second ={
            "2.50",//0
            "2.19",//1
            "2c01",//2
            "2c02",//3
            "2c11",//4
            "2.16",//5
            "2.10",//6
            "2.09",//7
            "2.08",//8
            "2.11",//9
            "2.02",//10
            "2.06",//11
            "2.07",//12
            "2.01",//13
            "2.18",//14
            "2.03",//15
            "2.25",//16
            "2.15",//17
            "2.51",//18
            "2.14",//19
    };
    String[] room_third ={
            "3.50",//0
            "3.33",//1
            "3.51",//2
            "3.42",//3
            "3.39",//4
            "3.41",//5
            "3c01",//6
            "3c02",//7
            "3c03",//8
            "3c07",//9
            "3.20",//10
            "3.31",//11
            "3.19",//12
            "3.30",//13
            "3.01",//14
            "3.40",//15
            "3c04",//16
            "3c05",//17
    };
    String[] room_forth ={
            "4.50",
            "4.01",
            "4.05",
            "4.04",
            "4.06",
            "4.20",
            "4.31",
            "4.29",
            "4.27",
            "4.51",//9
            "4.17",//10
    };
    String[] room_fifth ={
            "5.50",//0
            "5.01",//1
            "5.12",//2
            "5.04",//3
            "5.05",//4
            "5.11",//5
            "5.51",//6
    };
    String[] room_sixth ={
            "6.50",
            "6.02",
            "6.01",

    };

    String[] get(int floorNumber){
        if(floorNumber==2) {
            return room_second;
        }else if(floorNumber==3){
            return room_third;
        }else if(floorNumber==1){
            return room_first;
        }else if(floorNumber==4){
            return room_forth;
        }else if(floorNumber==0){
            return room_zero;
        }else if(floorNumber==5){
            return room_fifth;
        }else{
            return room_sixth;
        }
    }
}
