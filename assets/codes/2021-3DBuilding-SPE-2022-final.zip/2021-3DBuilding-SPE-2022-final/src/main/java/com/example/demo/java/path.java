package com.example.demo.java;
import java.util.List;
public class path {
    List<Object> pathfinding(String location, String destination){
        boolean ifReverse = false;
        int floorNumber;//destination's room number
        int floorNumber_2;//location's floor number

        char ch = destination.charAt(0);
        floorNumber = (ch - '0');
        System.out.println("destination at " + floorNumber);


        room rf = new room();
        boolean check = rf.compare(floorNumber, destination);
        System.out.println(check);


        //get recentNode
        //String location = "3c02";
        char ch_b = location.charAt(0);
        floorNumber_2 = (ch_b - '0');
        System.out.println("location at " + floorNumber_2);


        room rf_b = new room();
        boolean check_b = rf_b.compare(floorNumber_2, location);
        System.out.println(check_b);

        if (check && check_b) {
            System.out.println("checked! two room numbers are both valid");
        } else {
            System.out.println("invalid room number");

        }
        //---------------------
        //convert room number to 0-19
        int roomNumber_0_9_destination;
        int roomNumber_0_9_location;
        roomNumber_0_9_destination = rf.find(floorNumber, destination);
        System.out.println("destination number is " + roomNumber_0_9_destination);
        roomNumber_0_9_location = rf.find(floorNumber_2, location);
        System.out.println("location number is " + roomNumber_0_9_location);
        //check if two rooms are same
        if(roomNumber_0_9_destination!=roomNumber_0_9_location || floorNumber!=floorNumber_2){
            System.out.println("checked! two rooms are different");
        }else{
            System.out.println("they are exact same room");
        }
        //2c14 - 2.18 bug
        if(floorNumber==floorNumber_2&&roomNumber_0_9_destination==0){
            roomNumber_0_9_destination=roomNumber_0_9_location;
            roomNumber_0_9_location=0;
            ifReverse = true;
        }


        runner run = new runner();


        List<Object> fin;
        if (floorNumber == floorNumber_2) {
            fin = run.result_s(roomNumber_0_9_destination, floorNumber, roomNumber_0_9_location,ifReverse);
        } else {
            fin = run.result_d(roomNumber_0_9_destination, floorNumber, roomNumber_0_9_location, floorNumber_2);
        }
        System.out.println("finished here");
        return fin;
    }
    public static void main(String[] args) {
        path p = new path();
        List<Object> result = p.pathfinding("4.27","6.01");
        System.out.println(result);
    }
}
