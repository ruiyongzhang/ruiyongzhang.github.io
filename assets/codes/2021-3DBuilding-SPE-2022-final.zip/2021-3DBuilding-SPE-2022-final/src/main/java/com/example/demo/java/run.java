package com.example.demo.java;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
@Controller
// here is where we run pathfinding
public class run {
    boolean ifReverse = false;
    @RequestMapping("/a1")

    //String name is the destination
    //string origin is location
    //haven't added location box and button
    public void main(String name , String origin,HttpServletResponse response) throws IOException {
    //public static void main(String[] args) {
        int floorNumber;//destination's room number
        int floorNumber_2;//location's floor number


        //test here !!!!!!!!!!!!!!
        //String name = "005";
        char ch = name.charAt(0);
        //here goes the test
        floorNumber = (ch - '0');
        System.out.println("destination at " + floorNumber);
        
        
        room rf = new room();
        boolean check = rf.compare(floorNumber, name);
        System.out.println(check);


        //get recentNode
        //here goes the test
        //String origin = "012";
        char ch_b = origin.charAt(0);
        floorNumber_2 = (ch_b - '0');
        System.out.println("location at " + floorNumber_2);


        room rf_b = new room();
        boolean check_b = rf_b.compare(floorNumber_2, origin);
        System.out.println(check_b);

        if (check && check_b) {
            System.out.println("checked! two room numbers are both valid");
        } else {
            response.getWriter().print("invalid room number");

        }
        //---------------------
        //convert room number to 0-19
        int roomNumber_0_9_destination;
        int roomNumber_0_9_location;
        roomNumber_0_9_destination = rf.find(floorNumber, name);
        System.out.println("destination number is " + roomNumber_0_9_destination);
        roomNumber_0_9_location = rf.find(floorNumber_2, origin);
        System.out.println("location number is " + roomNumber_0_9_location);
        //check if two rooms are same
        // here check c is to find out whether two rooms are same
        boolean check_c = true;
        if(roomNumber_0_9_destination!=roomNumber_0_9_location || floorNumber!=floorNumber_2){
            System.out.println("checked! two rooms are different");
        }else{
            System.out.println("they are exact same room");
            response.getWriter().print("they are exact same room");
            check_c = false;
        }
        //2c14 - 2.18 bug
        if(floorNumber==floorNumber_2&&roomNumber_0_9_destination==0){
            roomNumber_0_9_destination=roomNumber_0_9_location;
            roomNumber_0_9_location=0;
            ifReverse = true;
        }


        runner run = new runner();

        if(check && check_b && check_c) {
            List<Object> fin;
            if (floorNumber == floorNumber_2) {
                fin = run.result_s(roomNumber_0_9_destination, floorNumber, roomNumber_0_9_location, ifReverse);
            } else {
                fin = run.result_d(roomNumber_0_9_destination, floorNumber, roomNumber_0_9_location, floorNumber_2);
            }
            System.out.println(fin);

            response.getWriter().print(fin);
        }
        System.out.println("finished here");
    }
}




