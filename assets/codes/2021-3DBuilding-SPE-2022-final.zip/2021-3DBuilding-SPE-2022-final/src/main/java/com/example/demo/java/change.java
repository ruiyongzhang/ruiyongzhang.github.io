package com.example.demo.java;
import java.util.ArrayList;
import java.util.List;

public class change {
    List<Object> processToFinal(List<Object> destination,List<Object> location){
        int length_l = location.size();
        List<Object> fin = new ArrayList<>();
        for(int i=0;i<length_l;i++){
            fin.add(location.get(length_l-i-1));
        }
        fin.addAll(destination);
        // fin combine two strings together
        // get location backwards and destination forward
        return fin;
    }
    List<Object> numberToChar(List<Object> list,int floorNumber,int change){
        roomLocator r = new roomLocator();
        String[] str = r.get(floorNumber);//use get method to get the floorNumber
        //
        List<Object> result = new ArrayList<>();
        if(change==0){
            for (Object o : list) {
                if (o.equals(1)) {
                    result.add(str[1]);
                } else if (o.equals(2)) {
                    result.add(str[2]);
                } else if (o.equals(3)) {
                    result.add(str[3]);
                } else if (o.equals(4)) {
                    result.add(str[4]);
                } else if (o.equals(5)) {
                    result.add(str[5]);
                } else if (o.equals(6)) {
                    result.add(str[6]);
                } else if (o.equals(7)) {
                    result.add(str[7]);
                } else if (o.equals(8)) {
                    result.add(str[8]);
                } else if (o.equals(9)) {
                    result.add(str[9]);
                } else if (o.equals(0)) {
                    result.add(str[0]);
                }else if (o.equals(10)) {
                    result.add(str[10]);
                } else if (o.equals(11)) {
                    result.add(str[11]);
                } else if (o.equals(12)) {
                    result.add(str[12]);
                } else if (o.equals(13)) {
                    result.add(str[13]);
                } else if (o.equals(14)) {
                    result.add(str[14]);
                } else if (o.equals(15)) {
                    result.add(str[15]);
                } else if (o.equals(16)) {
                    result.add(str[16]);
                } else if (o.equals(17)) {
                    result.add(str[17]);
                } else if (o.equals(18)) {
                    result.add(str[18]);
                } else if (o.equals(19)) {
                    result.add(str[19]);
                }
            }
        }else{
            for (Object o : list) {
                if (o.equals(change)) {
                    result.add(str[0]);
                } else if (o.equals(0)) {
                    result.add(str[change]);
                } else if (o.equals(1)) {
                    result.add(str[1]);
                } else if (o.equals(2)) {
                    result.add(str[2]);
                } else if (o.equals(3)) {
                    result.add(str[3]);
                } else if (o.equals(4)) {
                    result.add(str[4]);
                } else if (o.equals(5)) {
                    result.add(str[5]);
                } else if (o.equals(6)) {
                    result.add(str[6]);
                } else if (o.equals(7)) {
                    result.add(str[7]);
                } else if (o.equals(8)) {
                    result.add(str[8]);
                } else if (o.equals(9)) {
                    result.add(str[9]);
                } else if (o.equals(10)) {
                    result.add(str[10]);
                } else if (o.equals(11)) {
                    result.add(str[11]);
                } else if (o.equals(12)) {
                    result.add(str[12]);
                } else if (o.equals(13)) {
                    result.add(str[13]);
                } else if (o.equals(14)) {
                    result.add(str[14]);
                } else if (o.equals(15)) {
                    result.add(str[15]);
                } else if (o.equals(16)) {
                    result.add(str[16]);
                } else if (o.equals(17)) {
                    result.add(str[17]);
                } else if (o.equals(18)) {
                    result.add(str[18]);
                } else if (o.equals(19)) {
                    result.add(str[19]);
                }
            }
        }
        return result;
    }
}
