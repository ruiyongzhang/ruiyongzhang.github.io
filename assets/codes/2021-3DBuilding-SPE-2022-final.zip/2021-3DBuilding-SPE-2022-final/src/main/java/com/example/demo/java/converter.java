package com.example.demo.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
// the class converter is used to change a list of data for distance from room '0' to others
// to a list of the shortest path
public class converter {
    public List<Object> sequence(int[] seq, int index){
        List<Object> se = new ArrayList<>();
        Stack<Integer> vStack = new Stack<>();
        int v = seq[index];
        vStack.add(index);
        while (v != -1) {
            vStack.add(v);
            //System.out.println(v);
            v = seq[v];
        }
        while (!vStack.isEmpty()) {
            se.add(vStack.pop());
        }
        return se;
    }

    public static void main(String[] args){
        converter test = new converter();
        int[] a = {-1,1,0,2,3,6,4};
        List<Object> l = test.sequence(a,5);
        System.out.println(l);
    }
}
