package com.example.demo.java;


// here is a interesting part.
//I used matrix to store data, and the pathfinding algorithm always find the shortest
//path from matrix[0] to another room
//consequently, there is a matrix class to rearrange matrix for starting moving from any rooms
public class matrix {

void print(int[][] matrix){
        for (int[] ints : matrix) {
            for (int j = 0; j < matrix.length; j++) {
                System.out.print(ints[j] + " ");
            }
            System.out.println();
        }
    }
    //把0和6的数互换
    int[][] changeMatrix(int[][] matrix,int locationRoomNumber){
        int[][] result = new int[20][20];
        for(int i=0;i<matrix.length;i++){
            for(int j=0;j< matrix.length;j++){
                if(j==i){
                    result[i][j]=0;//diagonal are all 0；
                }else if(i==0){//here is the logic for row 0
                    // important : we are calculating points from 6 to others
                    // but now we have 0 and 6 switched
                    // I write this if else to switch room numbers
                    if(j==locationRoomNumber){
                        result[i][j]=matrix[0][locationRoomNumber];
                    }else {
                        result[i][j] = matrix[j][locationRoomNumber];
                    }
                }else if(i==locationRoomNumber){//6 th row logic
                    if(j==0){
                        result[i][j] = matrix[j][locationRoomNumber];
                    }else {
                        result[i][j] = matrix[j][0];
                    }
                }else{
                    //rest
                    if(j==0){
                        result[i][j]=matrix[i][locationRoomNumber];
                    }else if(j==locationRoomNumber){
                        result[i][j]=matrix[i][0];
                    }else{
                        result[i][j]=matrix[i][j];
                    }
                }
            }
        }
        return result;
    }
    public static void main(String[] args) {
        matrix m = new matrix();
        floor f = new floor();
        m.changeMatrix(f.get(4),8);

    }
}
