package com.example.demo.java;


// here is the pathfinding algorithm
// I used Dijkstra

public class dPathfinding {
    public int[] score(int[][] matrix){
        int[] scores = new int[matrix.length];
        //int[] nodeTrace = new int[node];
        boolean[] check = new boolean[matrix.length];
        check[0]=true;
        //initialize the distance between vertex 0 and other vertex;
        for(int i=1 ; i < matrix.length; i++ ){
            scores[i] = matrix[0][i];
            check[0] = false;
        }
        //
        for(int i = 0; i< matrix.length ; i++){
            int currentNode = 0;
            int distance = 1000;
            for(int j=0; j< matrix.length; j++){
                //
                if(!check[j]){
                    //
                    if(scores[j]<distance && scores[j]!= -1){
                        currentNode = j;
                        distance = scores[j];
                    }
                }
            }
            // check
            check[currentNode]= true;
            for(int j=0; j< matrix.length; j++){
                if (!check[j]){
                    if (matrix[currentNode][j] != -1 && (scores[j] > distance + matrix[currentNode][j] || scores[j] == -1)){
                        scores[j] = distance + matrix[currentNode][j];
                    }
                }
            }

        }
        return scores;
    }
    public int[] trace(int[][] matrix){
        int[] nodeTrace = new int[matrix.length]; // save last node
        // initialize the trace by putting 0 for every node
        for (int i = 1; i< matrix.length; i++){
                nodeTrace[i] = 0;
        }
        nodeTrace[0]=-1;
        //重新写一遍 score
        int[] scores = new int[matrix.length];
        boolean[] check = new boolean[matrix.length];
        check[0]=true;
        //initialize the distance between vertex 0 and other vertex;
        for(int i=1 ; i < matrix.length; i++ ){
            scores[i] = matrix[0][i];
            check[0] = false;
        }
        //shortest distance
        for(int i = 0; i< matrix.length ; i++){
            int currentNode = 0;
            int distance = 1000;
            for(int j=0; j< matrix.length; j++){
                //start to picking up if I haven't checked yet
                //find its shortest path
                if(!check[j]){
                    //less than minimum distance
                    if(scores[j]<distance && scores[j]!= -1){
                        currentNode = j;
                        distance = scores[j];
                    }
                }
            }
            // check
            check[currentNode]= true;

            //nodeTrace[currentNode]= 0; //initial point
            for(int j=0; j< matrix.length; j++){
                if (!check[j]){
                    if (matrix[currentNode][j] != -1 && (scores[j] > distance + matrix[currentNode][j] || scores[j] == -1)){
                        scores[j] = distance + matrix[currentNode][j];
                        nodeTrace[j]=currentNode;
                    }
                }
            }
        }
        return nodeTrace;
    }

}
