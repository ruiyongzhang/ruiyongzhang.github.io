package com.example.demo.java;
//the room numbers are stored here
public class room {
    char[][] room_zero = {
            {'0', '5', '0'},//0
            {'0', '0', '2'},//1
            {'0', '0', '1'},//2
            {'0', '0', '5'},//3
            {'0', '1', '0'},//4
            {'0', '0', '9'},//5
            {'0', 'c', '0', '1'},//6
            {'0', 'c', '0', '2'},//7
            {'0', '1', '2'},//8
            {'0', 'c', '1', '0'},//9
            {'0','0','4'},//10
            {'0','0','3'},//11
            {'0','0','8'},//12
            {'0','1','1'},//13
            {'0','c','0','5'},//14
            {'0','c','0','3'},//15
            {'0','c','1','1'},//16
            {'0','c','1','3'},//17
            {'0','c','1','4'},//18
            {'0','c','2','1'},//19
    };
    char[][] room_first = {
            {'1', '.', '5', '0'},//0
            {'1', '.', '1', '0'},//1
            {'1', '.', '0', '6'},//2
            {'1', '.', '0', '7'},//3
            {'1', '.', '0', '8'},//4
            {'1', '.', '1', '4'},//5
            {'1', '.', '1', '1'},//6
            {'1', 'c', '0', '2'},//7
            {'1', 'c', '0', '3'},//8
            {'1', 'c', '1', '0'},//9
            {'1', '.', '0', '3'},//10
            {'1', '.', '0', '2'},//11
            {'1', '.', '0', '4'},//12
            {'1', '.', '0', '9'},//13
            {'1', '.', '5', '1'},//14
            {'1', 'c', '0', '1'},//15
            {'1', '.', '1', '2'},//16
            {'1', 'c', '1', '1'},//17
    };
    char[][] room_second = {
            {'2','.','5','0'},//0
            {'2','.','1','9'},//1
            {'2','c','0','1'},//2
            {'2','c','0','2'},//3
            {'2','c','1','1'},//4
            {'2','.','1','6'},//5
            {'2','.','1','0'},//6
            {'2','.','0','9'},//7
            {'2','.','0','8'},//8
            {'2','.','1','1'},//9
            {'2','.','0','2'},//10
            {'2','.','0','6'},//11
            {'2','.','0','7'},//12
            {'2','.','0','1'},//13
            {'2','.','1','8'},//14
            {'2','.','0','3'},//15
            {'2','.','2','5'},//16
            {'2','.','1','5'},//17
            {'2','.','5','1'},//18
            {'2','.','1','4'},//19

    };
    char[][] room_third ={
            {'3','.','5','0'},//0
            {'3','.','3','3'},//1
            {'3','.','5','1'},//2
            {'3','.','4','2'},//3
            {'3','.','3','9'},//4
            {'3','.','4','1'},//5
            {'3','c','0','1'},//6
            {'3','c','0','2'},//7
            {'3','c','0','3'},//8
            {'3','c','0','7'},//9
            {'3','.','2','0'},//10
            {'3','.','3','1'},//11
            {'3','.','1','9'},//12
            {'3','.','3','0'},//13
            {'3','.','0','1'},//14
            {'3','.','4','0'},//15
            {'3','c','0','4'},//16
            {'3','c','0','5'},//17
    };
    char[][] room_forth ={
            {'4','.','5','0'},
            {'4','.','0','1'},
            {'4','.','0','5'},
            {'4','.','0','4'},
            {'4','.','0','6'},
            {'4','.','2','0'},
            {'4','.','3','1'},
            {'4','.','2','9'},
            {'4','.','2','7'},
            {'4','.','5','1'},//9
            {'4','.','1','7'},//10
    };
    char[][] room_fifth ={
            {'5','.','5','0'},//0
            {'5','.','0','1'},//1
            {'5','.','1','2'},//2
            {'5','.','0','4'},//3
            {'5','.','0','5'},//4
            {'5','.','1','1'},//5
            {'5','.','5','1'},//6
    };
    char[][] room_sixth ={
            {'6','.','5','0'},
            {'6','.','0','2'},
            {'6','.','0','1'},

    };
    char[][] get(int floorNumber){
        if(floorNumber==2) {
            return room_second;
        }else if(floorNumber==3){
            return room_third;
        }else if(floorNumber==1){
            return room_first;
        }else if(floorNumber==0){
            return room_zero;
        }else if(floorNumber==4){
            return room_forth;
        }else if(floorNumber==5){
            return room_fifth;
        }else{
            return room_sixth;
        }
    }


    // this is to find the number 0-9 stand for which room
    int find(int floorNumber,String roomNumber){
        int remember=0;//0is the default number
        int helper = 0;
        int helper_2= 0;
        int length = roomNumber.length();
        room r2 = new room();
        char[][] str = r2.get(floorNumber);
        for(int i=0;i<str.length;i++)
        {
            for(int j=0;j<length;j++)
            {if(str[i].length == length) {
                if (roomNumber.charAt(helper_2) == str[i][j]) {
                    helper++;
                    helper_2++;
                }
            }
                if (helper == length){
                    remember = i;
                    break;
                }
            }
            helper=0;
            helper_2=0;
        }
        return remember;
    }


    // this is to find the room's 0-9number
    boolean compare(int floorNumber,String roomNumber){
        int helper = 0;
        int helper_2= 0;
        int length = roomNumber.length();

        System.out.println(length);
        System.out.println(roomNumber);

        boolean check = false;
        room r2 = new room();
        char[][] str = r2.get(floorNumber);
        for (char[] chars : str) {
            for (int j = 0; j < length; j++) {
                if(length == chars.length) {
                    if (roomNumber.charAt(helper_2) == chars[j]) {
                        helper++;
                        helper_2++;
                    }
                }
                if (helper == length) {
                    check = true;
                    break;
                }
            }
            helper = 0;
            helper_2 = 0;
        }
        return check;
    }

}
