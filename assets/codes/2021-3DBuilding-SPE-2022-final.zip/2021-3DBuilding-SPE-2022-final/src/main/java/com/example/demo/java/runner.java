package com.example.demo.java;

import java.util.Collections;

import java.util.List;
// runner is where we use dPathfinding to get the correct sequence and send it back
public class runner {

    List<Object> result_s(int destination, int floorNumber, int location,boolean ifReverse){
        dPathfinding test = new dPathfinding();
        floor a = new floor();
        matrix ma = new matrix();
        int[][] matrix = ma.changeMatrix(a.get(floorNumber),location);
        int[] result = test.trace(matrix);
        converter converted_result = new converter();
        List<Object> l = converted_result.sequence(result, destination);
        System.out.println("l is"+l);
        System.out.println(destination);
        System.out.println(location);
        change cha = new change();
        //gai这里
        //put in a method to reverse the list if the destination is 0 node
        if (ifReverse){
            Collections.reverse(l);
            System.out.println("hello");
        }
        System.out.println("l is"+l);
        List<Object> l2 = cha.numberToChar(l,floorNumber,location);
        System.out.println("l2 is");
        System.out.println(l2);
        return(l2);
    }
    List<Object> result_d(int destination,int d_floorNumber, int location, int l_floorNumber){
        dPathfinding test = new dPathfinding();
        floor a = new floor();
        //这里的get()里面写的应该是floorNumber
        int[][] matrix = a.get(l_floorNumber);
        int[] result2 = test.trace(matrix);
        converter converted_result = new converter();
        List<Object> l = converted_result.sequence(result2, location);
        change cha = new change();
        List<Object> l2 = cha.numberToChar(l,l_floorNumber,0);
        System.out.println("l2 is");
        System.out.println(l2);
        //destination part
        int[][] matrix_d = a.get(d_floorNumber);
        int[] result2_d = test.trace(matrix_d);
        converter converted_result_d = new converter();
        List<Object> l_d = converted_result_d.sequence(result2_d, destination);
        change cha_d = new change();
        List<Object> l2_d = cha_d.numberToChar(l_d,d_floorNumber,0);
        System.out.println("l2_d is");
        System.out.println(l2_d);
        //List<Integer> r = test.sequence(result2,6);
        return cha.processToFinal(l2_d,l2);
    }

}
