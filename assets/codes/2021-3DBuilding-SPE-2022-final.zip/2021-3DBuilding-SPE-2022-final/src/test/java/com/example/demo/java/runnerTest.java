package com.example.demo.java;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class runnerTest {
    @Test
    void pathfinding(){
        
        assertEquals(1,1);
    }
}