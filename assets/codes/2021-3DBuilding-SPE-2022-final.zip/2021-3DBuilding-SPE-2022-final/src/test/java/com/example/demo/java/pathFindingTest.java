package com.example.demo.java;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;


class pathFindingTest {
    @Test
    void pathfinding_floor0_1(){
        path p = new path();
        String location = "050";
        String destination = "009";
        List<Object> exp = new ArrayList<>(Arrays.asList("050", "002", "001", "009"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor0_4(){
        path p = new path();
        String location = "005";
        String destination = "001";
        List<Object> exp = new ArrayList<>(Arrays.asList("005", "050", "002","001" ));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor0_2(){
        path p = new path();
        String location = "003";
        String destination = "0c21";
        List<Object> exp = new ArrayList<>(Arrays.asList("003", "004", "005", "050","002","001","0c01","0c02","0c10","0c13","0c14","0c21"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor0_3(){
        path p = new path();
        String location = "009";
        String destination = "050";
        List<Object> exp = new ArrayList<>(Arrays.asList("009","001","002","050"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor0_5(){
        path p = new path();
        String location = "008";
        String destination = "050";
        List<Object> exp = new ArrayList<>(Arrays.asList("008","009","001","002","050"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor1_1(){
        path p = new path();
        String location = "1.02";
        String destination = "1.51";
        List<Object> exp = new ArrayList<>(Arrays.asList("1.02", "1.10", "1.14", "1.09","1.51"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor1_2(){
        path p = new path();
        String location = "1c11";
        String destination = "1.50";
        List<Object> exp = new ArrayList<>(Arrays.asList("1c11", "1c03", "1c02", "1.11","1.10","1.50"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor1_3(){
        path p = new path();
        String location = "1.50";
        String destination = "1c11";
        List<Object> exp = new ArrayList<>(Arrays.asList("1.50","1.10","1.11","1c02","1c03","1c11"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor2_1(){
        path p = new path();
        String location = "2.50";
        String destination = "2.19";
        List<Object> exp = new ArrayList<>(Arrays.asList("2.50", "2.18", "2.19"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor2_2(){
        path p = new path();
        String location = "2.19";
        String destination = "2.50";
        List<Object> exp = new ArrayList<>(Arrays.asList("2.19", "2.18", "2.50"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor2_3(){
        path p = new path();
        String location = "2.09";
        String destination = "2c11";
        List<Object> exp = new ArrayList<>(Arrays.asList("2.09", "2.10", "2.16","2c02","2c11"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor3_1(){
        path p = new path();
        String location = "3.01";
        String destination = "3c07";
        List<Object> exp = new ArrayList<>(Arrays.asList("3.01", "3.42", "3.39","3.40","3c02","3c03","3c07"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor3_2(){
        path p = new path();
        String location = "3.50";
        String destination = "3.30";
        List<Object> exp = new ArrayList<>(Arrays.asList("3.50", "3.01", "3.33","3.30"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor4_1(){
        path p = new path();
        String location = "4.01";
        String destination = "4.27";
        List<Object> exp = new ArrayList<>(Arrays.asList("4.01", "4.06", "4.20","4.31","4.29","4.27"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor4_2(){
        path p = new path();
        String location = "4.31";
        String destination = "4.05";
        List<Object> exp = new ArrayList<>(Arrays.asList("4.31", "4.20", "4.06","4.05"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor5(){
        path p = new path();
        String location = "5.01";
        String destination = "5.51";
        List<Object> exp = new ArrayList<>(Arrays.asList("5.01", "5.12","5.11","5.51"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor5_2(){
        path p = new path();
        String location = "5.04";
        String destination = "5.11";
        List<Object> exp = new ArrayList<>(Arrays.asList("5.04", "5.12","5.11"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor5_3(){
        path p = new path();
        String location = "5.04";
        String destination = "5.05";
        List<Object> exp = new ArrayList<>(Arrays.asList("5.04", "5.12","5.05"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }
    @Test
    void pathfinding_floor_6(){
        path p = new path();
        String location = "6.01";
        String destination = "6.50";
        List<Object> exp = new ArrayList<>(Arrays.asList("6.01", "6.02", "6.50"));
        List<Object> result = p.pathfinding(location,destination);
        assertEquals(exp,result);
    }

}